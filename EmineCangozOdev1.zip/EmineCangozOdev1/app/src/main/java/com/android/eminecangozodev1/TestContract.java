package com.android.eminecangozodev1;

public class TestContract {
    private TestContract() {
    }
    public static class QuestionsTable {
        public static final String TABLE_NAME = "test_questions";
        public static final String COLUMN_ID = "id";
        public static final String COLUMN_QUESTION = "soru";
        public static final String COLUMN_OPTION1 = "secenekA";
        public static final String COLUMN_OPTION2 = "secenekB";
        public static final String COLUMN_OPTION3 = "secenekC";
        public static final String COLUMN_OPTION4 = "secenekD";
        public static final String COLUMN_ANSWER_NR = "dogruSecenek";
        public static final String COLUMN_DIFF_LEVEL = "zorlukSeviyesi";
    }
}
