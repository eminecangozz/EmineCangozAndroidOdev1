package com.android.eminecangozodev1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.ArrayList;

import androidx.appcompat.app.AppCompatActivity;

public class UserSignupActivity extends AppCompatActivity {

    EditText etAd, etSoyad, etTel, etEmail, etSifre, etSifreTekrar;

    String ad, soyad, tel, email, sifre, sifreTekrar, resim;
    Button btnGirisYap;
    private ArrayList<Users> userList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_signup);
        tanimlamalar();
        try{
            userList = PrefConfig.sharedPreftenOku(this);
        }
        catch(Exception e){
            e.printStackTrace();
        }
        if (userList == null)
            userList = new ArrayList<>();
    }

    private void tanimlamalar() {
        etAd = findViewById(R.id.etAd);
        etSoyad = findViewById(R.id.etSoyad);
        etTel = findViewById(R.id.etTel);
        etEmail = findViewById(R.id.etEmailLogin);
        etSifre = findViewById(R.id.etSifreLogin);
        etSifreTekrar = findViewById(R.id.etSifreTekrar);
        btnGirisYap = findViewById(R.id.btnGirisYap);

    }

    public void btnResimYukleClick(View view) {
    }

    public void btnKayitOlClick(View view) {
        verileriAl();
        if (eksikVeriKontrol()) {
            if(sifreEslesmeKontrol(sifre, sifreTekrar))
            {
                Users user = new Users(ad, soyad, tel, email, sifre, resim);
                if(!uyeKayitliMiKontrol(ad))
                {
                    userList.add(user);
                    Toast.makeText(this, "Başarıyla Kaydedildi", Toast.LENGTH_SHORT).show();
                    usersListGoster();
                    PrefConfig.sharedPrefeArrayListEkle(this,userList);
                    btnGirisYap.setVisibility(View.VISIBLE);
                }
                else {
                    btnGirisYap.setVisibility(View.INVISIBLE);
                    Toast.makeText(this, "Bu üye kayıtlı!", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    private boolean uyeKayitliMiKontrol(String ad) {
        boolean deger=false;
        for (Users user : userList) {
            if(user.getAd().toString().equals(ad)){
                deger= true;
            }
            else {
                deger= false;
            }
        }
        return deger;
    }


    private void usersListGoster() {
        String uyeler = "";
        for (Users user : userList) {
            uyeler += user.getAd() + "\n";
        }
        Toast.makeText(this,"Kaydınız Tamamlandı. \n\nKayıtlı Üyelerimiz: \n"+ uyeler,
                Toast.LENGTH_SHORT).show();
    }

    private boolean eksikVeriKontrol() {
        if (ad.isEmpty() || soyad.isEmpty() || tel.isEmpty() || email.isEmpty() || sifre.isEmpty() || sifreTekrar.isEmpty()) {
            Toast.makeText(this, "Tüm alanları eksiksiz doldurunuz.", Toast.LENGTH_SHORT).show();
            return false;
        } else {
            return true;
        }
    }

    private void verileriAl() {
        ad = etAd.getText().toString();
        soyad = etSoyad.getText().toString();
        tel = etTel.getText().toString();
        email = etEmail.getText().toString();
        sifre = etSifre.getText().toString();
        sifreTekrar = etSifreTekrar.getText().toString();
    }

    private boolean sifreEslesmeKontrol(String s1, String s2) {
        if (!s1.equals(s2)) {
            Toast.makeText(this, "Şifreniz eşleşmedi. Kontrol ediniz.", Toast.LENGTH_SHORT).show();
            return false;
        } else
            return true;
    }

    public void btnGirisYapClick(View view) {
        Intent i=new Intent(getApplicationContext(),UserLoginActivity.class);
        startActivity(i);
    }
}