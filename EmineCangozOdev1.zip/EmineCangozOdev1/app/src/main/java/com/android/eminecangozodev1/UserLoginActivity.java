package com.android.eminecangozodev1;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class UserLoginActivity extends AppCompatActivity {

    private ArrayList<Users> userList;
    EditText etEmail, etSifre;
    int hataliGirisSayaci = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_login);
        if(!hariciKartIzinDurum()){
            hariciKartIzinIste();
        }
        etEmail = findViewById(R.id.etEmailLogin);
        etSifre = findViewById(R.id.etSifreLogin);
        try{
            userList = PrefConfig.sharedPreftenOku(this);
        }
        catch(Exception e){
            e.printStackTrace();
        }

        if (userList == null)
            userList = new ArrayList<>();
    }

    public void btnGirisYapClick(View view) {
        String email = etEmail.getText().toString();
        String sifre = etSifre.getText().toString();
        if (uyeKayitliMiKontrol(email, sifre)) {
            Toast.makeText(this, "Giriş Başarılı!", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(getApplicationContext(), MenuScreenActivity.class);
            startActivity(intent);
        } else {
            hataliGirisSayaci++;
            Toast.makeText(this, "Böyle bir kayıt bulunamadı. \n Bilgilerinizi Kontrol Edin" +
                            "\n Kalan deneme hakkı: " + (3 - hataliGirisSayaci),
                    Toast.LENGTH_SHORT).show();
            if (hataliGirisSayaci == 3)
                finish();
        }
    }

    public void btnKayitOlClick(View view) {
        Intent intent = new Intent(getApplicationContext(), UserSignupActivity.class);
        startActivity(intent);
    }

    private boolean uyeKayitliMiKontrol(String email, String sifre) {
        boolean deger = false;
        for (Users user : userList) {
            if (user.getEmail().toString().equals(email) && user.getSifre().toString().equals(sifre)) {
                deger = true;
            } else {
                deger = false;
            }
        }
        return deger;
    }

    private boolean hariciKartIzinDurum(){
        int haricidenOkumaIzni= ContextCompat.checkSelfPermission(this,
                Manifest.permission.READ_EXTERNAL_STORAGE);
        int hariciyeYazmaIzni=ContextCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE);
        return ((haricidenOkumaIzni== PackageManager.PERMISSION_GRANTED) && (hariciyeYazmaIzni==PackageManager.PERMISSION_GRANTED));
    }
    private void hariciKartIzinIste(){
        ActivityCompat.requestPermissions(this,
                new String[]{ Manifest.permission.READ_EXTERNAL_STORAGE,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE},100);
    }
}