package com.android.eminecangozodev1;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class CreateTestActivity extends AppCompatActivity {
    EditText etSinavSuresi,etSoruPuani,etSinavZorlukDuzeyi;
    RecyclerView recyclerView;
    ArrayList<Questions> liste;
    ArrayList<Questions> seciliSorular;
    String DOSYA_ADI = "";
    File externaldosya;
    File externalDizin;
    File path;
    String kayitliSinavSuresi,kayitliSoruPuani;
    int kayitliSinavZorlukDuzeyi;
    private SQLiteDatabase db;
    private static final String TAG = "CreateTestActivity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_test);
        spdeKayitliVerileriGetir();
        db = this.openOrCreateDatabase("Test", MODE_PRIVATE, null);
        recyclerView=findViewById(R.id.recyclerView2);
        liste=getAllQuestions(kayitliSinavZorlukDuzeyi);
        seciliSorular=new ArrayList<Questions>();

        LinearLayoutManager linearLayoutManager=new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(linearLayoutManager);

        SelectedQuestionAdapter adapter=new SelectedQuestionAdapter(liste,this,
                new SelectedQuestionAdapter.OnItemCheckListener() {
                    @Override
                    public void onItemCheck(Questions question) {
                        seciliSorular.add(question);
                    }

                    @Override
                    public void onItemUncheck(Questions question) {
                        seciliSorular.remove(question);
                    }
                });
        recyclerView.setAdapter(adapter);

        path = getFilesDir();
    }
    public String ZamanDosyaAdi() {
        return "txt_" + new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date()) + ".txt";
    }


    public ArrayList<Questions> getAllQuestions(int zorlukDuzeyi) {
        ArrayList<Questions> questionList = new ArrayList<>();

        String[] args={String.valueOf(zorlukDuzeyi)};
//        Cursor c = db.rawQuery("SELECT * FROM " + TestContract.QuestionsTable.TABLE_NAME +" WHERE" +
//                        " " + TestContract.QuestionsTable.COLUMN_DIFF_LEVEL+"=?", args);

        Cursor c = db.rawQuery("SELECT * FROM " + TestContract.QuestionsTable.TABLE_NAME +" WHERE zorlukSeviyesi=?",
                args);
        if (c.moveToFirst()) {
            do {
                Questions question = new Questions();
                question.setID(c.getInt(c.getColumnIndex(TestContract.QuestionsTable.COLUMN_ID)));
                question.setSoru(c.getString(c.getColumnIndex(TestContract.QuestionsTable.COLUMN_QUESTION)));
                question.setSecenekA(c.getString(c.getColumnIndex(TestContract.QuestionsTable.COLUMN_OPTION1)));
                question.setSecenekB(c.getString(c.getColumnIndex(TestContract.QuestionsTable.COLUMN_OPTION2)));
                question.setSecenekC(c.getString(c.getColumnIndex(TestContract.QuestionsTable.COLUMN_OPTION3)));
                question.setSecenekD(c.getString(c.getColumnIndex(TestContract.QuestionsTable.COLUMN_OPTION4)));
                question.setDogruSecenek(c.getInt(c.getColumnIndex(TestContract.QuestionsTable.COLUMN_ANSWER_NR)));
                question.setZorlukSeviyesi(c.getInt(c.getColumnIndex(TestContract.QuestionsTable.COLUMN_DIFF_LEVEL)));
                questionList.add(question);
            } while (c.moveToNext());
        }
        c.close();
        db.close();
        Log.d(TAG, "getAllQuestions: Sorular listelendi.");
        return questionList;
    }

    private void spdeKayitliVerileriGetir() {
        SharedPreferences sharedPref = this.getSharedPreferences("TestSettings",MODE_PRIVATE);
        kayitliSinavSuresi = sharedPref.getString("sinavSuresi","Kayıt Yok");
        kayitliSoruPuani = sharedPref.getString("soruPuani","Kayıt Yok");
        kayitliSinavZorlukDuzeyi = sharedPref.getInt("sinavZorlukDuzeyi",1);
        etSinavSuresi=findViewById(R.id.etSinavSuresi);
        etSoruPuani=findViewById(R.id.etSoruPuani);
        etSinavZorlukDuzeyi=findViewById(R.id.etSinavZorlukDuzeyi);
        etSinavSuresi.setText(kayitliSinavSuresi);
        etSoruPuani.setText(kayitliSoruPuani);
        etSinavZorlukDuzeyi.setText(kayitliSinavZorlukDuzeyi+"");
    }

    public void btnSinavOlusturClick(View view) {
        String sb="Sınav Süreniz: " +kayitliSinavSuresi + "dkdır. \n";
        sb+="Her soru "+ kayitliSoruPuani +"  puandır. \n";
        for(Questions q:seciliSorular)
        {
            sb+=q.getSoru() + "\n a) "
            +q.getSecenekA()+ "\n b) "+q.getSecenekB()+ "\n c) "+q.getSecenekC()+ "\n d) "+q.getSecenekD()+
                    "\n\n";
        }
       // Toast.makeText(this, sb, Toast.LENGTH_SHORT).show();

        DOSYA_ADI = ZamanDosyaAdi();
        if (!hariciKartIzinleriTamam())
            hariciKartIizinIste();

        File sdcard;
        //Android 9 sürümünde bu kod çalışıyor:
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q){
            File[] externalStorageVolumes =
                    ContextCompat.getExternalFilesDirs(getApplicationContext(), null);
            sdcard = externalStorageVolumes[1]; // 0 telefon hafızası 1 hafıza kartı
        }
        else{
            sdcard = Environment.getExternalStorageDirectory();
        }

        externalDizin = new File(sdcard.getAbsolutePath() + "/SınavDosyalari/");
        externalDizin.mkdir(); //Klasör oluşturuldu!
        externaldosya = new File(externalDizin, "/"+DOSYA_ADI); //dosya oluşturuldu
        try {
            FileOutputStream fos = new FileOutputStream(externaldosya);
            fos.write(sb.getBytes());
            fos.close();
            Toast.makeText(this, "Kayıt yeri: " + externaldosya,
                    Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "HATA KAYIT BAŞARISIZ.", Toast.LENGTH_SHORT).show();
        }


    }


    public void btnMailGonderClick(View view) {
        try {
            String filelocation = externaldosya+"";
            Intent intent = new Intent(Intent.ACTION_SENDTO);
            intent.setType("text/plain");
            String message="Sınav e-maile ekleniyor.";
            intent.putExtra(Intent.EXTRA_SUBJECT, "Subject");
            intent.putExtra(Intent.EXTRA_STREAM, Uri.parse( "file://"+filelocation));
            intent.putExtra(Intent.EXTRA_TEXT, message);
            intent.setData(Uri.parse("mailto:eminacangozz@gmail.com"));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

            startActivity(intent);
        } catch(Exception e)  {
            e.printStackTrace();
        }
    }

    private boolean hariciKartIzinleriTamam() {
        int haricikartakayit = ContextCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE);
        int haricikartokuma = ContextCompat.checkSelfPermission(this,
                Manifest.permission.READ_EXTERNAL_STORAGE);
        return haricikartakayit == PackageManager.PERMISSION_GRANTED && haricikartokuma == PackageManager.PERMISSION_GRANTED;
    }
    private void hariciKartIizinIste() {
        ActivityCompat.requestPermissions(this, new String[]{
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.READ_EXTERNAL_STORAGE
        }, 100);
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 100: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
                    Toast.makeText(this, "İzin Verildi", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(this, "İzin Verilmedi", Toast.LENGTH_SHORT).show();
            }
        }
    }
}