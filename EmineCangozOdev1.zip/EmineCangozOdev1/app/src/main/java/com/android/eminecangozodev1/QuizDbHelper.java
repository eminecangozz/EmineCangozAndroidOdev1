package com.android.eminecangozodev1;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.android.eminecangozodev1.TestContract.*;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.Nullable;

import static android.content.Context.MODE_PRIVATE;

public class QuizDbHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "Test";
    private static final int DATABASE_VERSION = 1;
    private SQLiteDatabase db;
    private static final String TAG = "QuizDbHelper";


    public QuizDbHelper(@Nullable Context context,  int version) {

        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        db=context.openOrCreateDatabase("Test", MODE_PRIVATE, null);
        onCreate(db);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        this.db = db;
        final String SQL_CREATE_QUESTIONS_TABLE = "CREATE TABLE IF NOT EXISTS " +
                QuestionsTable.TABLE_NAME + " ( " +
                QuestionsTable.COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                QuestionsTable.COLUMN_QUESTION + " TEXT, " +
                QuestionsTable.COLUMN_OPTION1 + " TEXT, " +
                QuestionsTable.COLUMN_OPTION2 + " TEXT, " +
                QuestionsTable.COLUMN_OPTION3 + " TEXT, " +
                QuestionsTable.COLUMN_OPTION4 + " TEXT, " +
                QuestionsTable.COLUMN_ANSWER_NR + " INTEGER, " +
                QuestionsTable.COLUMN_DIFF_LEVEL + " INTEGER" +
                ")";
        db.execSQL(SQL_CREATE_QUESTIONS_TABLE);
        Log.d(TAG, "onCreate: "+"Veritabanı yaratıldı.");
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + QuestionsTable.TABLE_NAME);
        onCreate(db);
    }

    public void soruekle(Questions question) {
        ContentValues cv = new ContentValues();
        cv.put(TestContract.QuestionsTable.COLUMN_QUESTION, question.getSoru());
        cv.put(TestContract.QuestionsTable.COLUMN_OPTION1, question.getSecenekA());
        cv.put(TestContract.QuestionsTable.COLUMN_OPTION2, question.getSecenekB());
        cv.put(TestContract.QuestionsTable.COLUMN_OPTION3, question.getSecenekC());
        cv.put(TestContract.QuestionsTable.COLUMN_OPTION4, question.getSecenekD());
        cv.put(TestContract.QuestionsTable.COLUMN_ANSWER_NR, question.getDogruSecenek());
        cv.put(TestContract.QuestionsTable.COLUMN_DIFF_LEVEL, question.getZorlukSeviyesi());
        db.insert(TestContract.QuestionsTable.TABLE_NAME, null, cv);
        Log.d(TAG, "addQuestion: Soru Eklendi.");

    }

    public long soruGuncelle(Questions question,int updateid){
        ContentValues cv = new ContentValues();
//        cv.put(QuestionsTable.COLUMN_ID, question.getID());
        cv.put(TestContract.QuestionsTable.COLUMN_QUESTION, question.getSoru());
        cv.put(TestContract.QuestionsTable.COLUMN_OPTION1, question.getSecenekA());
        cv.put(TestContract.QuestionsTable.COLUMN_OPTION2, question.getSecenekB());
        cv.put(TestContract.QuestionsTable.COLUMN_OPTION3, question.getSecenekC());
        cv.put(TestContract.QuestionsTable.COLUMN_OPTION4, question.getSecenekD());
        cv.put(TestContract.QuestionsTable.COLUMN_ANSWER_NR, question.getDogruSecenek());
        cv.put(TestContract.QuestionsTable.COLUMN_DIFF_LEVEL, question.getZorlukSeviyesi());

        long result=db.update(QuestionsTable.TABLE_NAME,cv,"id=?",new String[]{String.valueOf(updateid)});
        return result;
    }

    public void deleteQuestion(int id){
         db.execSQL("DELETE FROM "+QuestionsTable.TABLE_NAME +" WHERE "+QuestionsTable.COLUMN_ID+"="+id);
    }


    public List<Questions> getAllQuestions() {
        List<Questions> questionList = new ArrayList<>();
        db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM " + QuestionsTable.TABLE_NAME, null);
        if (c.moveToFirst()) {
            do {
                Questions question = new Questions();
                question.setSoru(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_QUESTION)));
                question.setSecenekA(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION1)));
                question.setSecenekB(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION2)));
                question.setSecenekC(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION3)));
                question.setSecenekD(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION4)));
                question.setDogruSecenek(c.getInt(c.getColumnIndex(QuestionsTable.COLUMN_ANSWER_NR)));
                question.setZorlukSeviyesi(c.getInt(c.getColumnIndex(QuestionsTable.COLUMN_DIFF_LEVEL)));
                questionList.add(question);
            } while (c.moveToNext());
        }
        c.close();
        Log.d(TAG, "getAllQuestions: Sorular listelendi.");
        return questionList;
    }

    public Questions getOneQuestion(int id){
        Questions question;
        db = getReadableDatabase();
        Log.d(TAG, "getOneQuestion"+id);
        String[] ids={String.valueOf(id)};
        Cursor c =
                db.rawQuery("SELECT * FROM " + QuestionsTable.TABLE_NAME+" WHERE "+QuestionsTable.COLUMN_ID+"=?",ids);

        c.moveToFirst();
                question = new Questions();
                question.setSoru(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_QUESTION)));
                question.setSecenekA(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION1)));
                question.setSecenekB(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION2)));
                question.setSecenekC(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION3)));
                question.setSecenekD(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION4)));
                question.setDogruSecenek(c.getInt(c.getColumnIndex(QuestionsTable.COLUMN_ANSWER_NR)));
                question.setZorlukSeviyesi(c.getInt(c.getColumnIndex(QuestionsTable.COLUMN_DIFF_LEVEL)));

        c.close();
        return question;
    }
}
