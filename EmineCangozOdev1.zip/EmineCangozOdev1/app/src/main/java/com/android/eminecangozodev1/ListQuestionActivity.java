package com.android.eminecangozodev1;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;

import java.util.ArrayList;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class ListQuestionActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<Questions> liste;
    private SQLiteDatabase db;
    private static final String TAG = "ListQuestionActivity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_question);
        db = this.openOrCreateDatabase("Test", MODE_PRIVATE, null);
        recyclerView=findViewById(R.id.recyclerView);
//        liste=new ArrayList<Questions>();
//        liste.add(new Questions("Soru","A","B","C","D",1,2));
//        liste.add(new Questions("Soru uzunca","A","B","C","D",1,2));
//        liste.add(new Questions("Soru kısacaaa","A","B","C","D",1,2));
        liste=getAllQuestions();

        LinearLayoutManager linearLayoutManager=new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(linearLayoutManager);

        QuestionAdapter adapter=new QuestionAdapter(liste,this);
        recyclerView.setAdapter(adapter);


//        GridLayoutManager gridLayoutManager=new GridLayoutManager(this,2);
//        recyclerView.setLayoutManager(gridLayoutManager);

    }

    public ArrayList<Questions> getAllQuestions() {
        ArrayList<Questions> questionList = new ArrayList<>();

        Cursor c = db.rawQuery("SELECT * FROM " + TestContract.QuestionsTable.TABLE_NAME, null);
        if (c.moveToFirst()) {
            do {
                Questions question = new Questions();
                question.setID(c.getInt(c.getColumnIndex(TestContract.QuestionsTable.COLUMN_ID)));
                question.setSoru(c.getString(c.getColumnIndex(TestContract.QuestionsTable.COLUMN_QUESTION)));
                question.setSecenekA(c.getString(c.getColumnIndex(TestContract.QuestionsTable.COLUMN_OPTION1)));
                question.setSecenekB(c.getString(c.getColumnIndex(TestContract.QuestionsTable.COLUMN_OPTION2)));
                question.setSecenekC(c.getString(c.getColumnIndex(TestContract.QuestionsTable.COLUMN_OPTION3)));
                question.setSecenekD(c.getString(c.getColumnIndex(TestContract.QuestionsTable.COLUMN_OPTION4)));
                question.setDogruSecenek(c.getInt(c.getColumnIndex(TestContract.QuestionsTable.COLUMN_ANSWER_NR)));
                question.setZorlukSeviyesi(c.getInt(c.getColumnIndex(TestContract.QuestionsTable.COLUMN_DIFF_LEVEL)));
                questionList.add(question);
            } while (c.moveToNext());
        }
        c.close();
        Log.d(TAG, "getAllQuestions: Sorular listelendi.");
        return questionList;
    }
}