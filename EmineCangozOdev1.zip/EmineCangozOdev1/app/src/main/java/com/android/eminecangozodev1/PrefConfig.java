package com.android.eminecangozodev1;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class PrefConfig {
    private static final String LIST_KEY = "listkey";
    private static final String TAG = "PrefConfig";
    public static void sharedPrefeArrayListEkle(Context context, ArrayList<Users> users) {
        Log.d(TAG, "sharedPrefeArrayListEkle: ");
        Gson gson = new Gson();
        String jsonString = gson.toJson(users);
        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString(LIST_KEY, jsonString);
        editor.apply();
    }

    public static ArrayList<Users> sharedPreftenOku(Context context){
        Log.d(TAG, "sharedPreftenOku: ");
        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(context);
        String jsonString = pref.getString(LIST_KEY,"");
        Gson gson = new Gson();
        Type type=new TypeToken<ArrayList<Users>>(){}.getType();
        ArrayList<Users> users=gson.fromJson(jsonString,type);
        Log.d(TAG, "sharedPreftenOku: "+users.get(0).getEmail()+   "sifre:"+users.get(0).getSifre());
        return users;
    }
}
