package com.android.eminecangozodev1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class MenuScreenActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_screen);
    }

    public void btnSinavAyarlariClick(View view) {
        Intent intent=new Intent(getApplicationContext(),TestSettingsActivity.class);
        startActivity(intent);
    }

    public void btnSoruEkleClick(View view) {
        Intent intent=new Intent(getApplicationContext(),AddQuestionActivity.class);
        startActivity(intent);
    }

    public void btnSoruListeleClick(View view) {
        Intent intent=new Intent(getApplicationContext(),ListQuestionActivity.class);
        startActivity(intent);
    }

    public void btnSinavOlusturClick(View view) {
        Intent intent=new Intent(getApplicationContext(),CreateTestActivity.class);
        startActivity(intent);
    }
}