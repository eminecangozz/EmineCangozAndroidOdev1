package com.android.eminecangozodev1;

public class Questions {
    private int ID;
    private String soru;
    private String secenekA;
    private String secenekB;
    private String secenekC;
    private String secenekD;
    private int dogruSecenek;
    private int zorlukSeviyesi;

    public Questions() {
    }

    public Questions(String soru, String secenekA, String secenekB, String secenekC,
                     String secenekD, int dogruSecenek, int zorlukSeviyesi) {
        this.soru = soru;
        this.secenekA = secenekA;
        this.secenekB = secenekB;
        this.secenekC = secenekC;
        this.secenekD = secenekD;
        this.dogruSecenek = dogruSecenek;
        this.zorlukSeviyesi = zorlukSeviyesi;
    }
    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getSoru() {
        return soru;
    }

    public void setSoru(String soru) {
        this.soru = soru;
    }

    public String getSecenekA() {
        return secenekA;
    }

    public void setSecenekA(String secenekA) {
        this.secenekA = secenekA;
    }

    public String getSecenekB() {
        return secenekB;
    }

    public void setSecenekB(String secenekB) {
        this.secenekB = secenekB;
    }

    public String getSecenekC() {
        return secenekC;
    }

    public void setSecenekC(String secenekC) {
        this.secenekC = secenekC;
    }

    public String getSecenekD() {
        return secenekD;
    }

    public void setSecenekD(String secenekD) {
        this.secenekD = secenekD;
    }

    public int getDogruSecenek() {
        return dogruSecenek;
    }

    public void setDogruSecenek(int dogruSecenek) {
        this.dogruSecenek = dogruSecenek;
    }

    public int getZorlukSeviyesi() {
        return zorlukSeviyesi;
    }

    public void setZorlukSeviyesi(int zorlukSeviyesi) {
        this.zorlukSeviyesi = zorlukSeviyesi;
    }
}
