package com.android.eminecangozodev1;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class SelectedQuestionAdapter extends RecyclerView.Adapter<SelectedQuestionAdapter.RecyclerViewHolder> {

    interface OnItemCheckListener {
        void onItemCheck(Questions question);
        void onItemUncheck(Questions question);
    }
    @NonNull
    private OnItemCheckListener onItemClick;

    private SQLiteDatabase db;
    private static final String TAG = "QuestionAdapter";
    ArrayList<Questions> questionsArrayList;
    Context context;

    public SelectedQuestionAdapter(ArrayList<Questions> questionsArrayList,Context context,@NonNull OnItemCheckListener onItemCheckListener) {
        this.questionsArrayList = questionsArrayList;
        this.context=context;
        this.onItemClick = onItemCheckListener;

    }
    @NonNull
    @Override
    public SelectedQuestionAdapter.RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater=LayoutInflater.from(parent.getContext());

        View view=layoutInflater.inflate(R.layout.layout_selectedrecyclerview_row , parent,false);
        return new SelectedQuestionAdapter.RecyclerViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final SelectedQuestionAdapter.RecyclerViewHolder holder, final int position) {
        final Questions currentItem = questionsArrayList.get(position);
        holder.tvSoru.setText(questionsArrayList.get(position).getSoru());
        holder.tvDogruSecenek.setText("Doğru Seçenek = "+questionsArrayList.get(position).getDogruSecenek()+"");
        holder.rbA.setText(questionsArrayList.get(position).getSecenekA());
        holder.rbB.setText(questionsArrayList.get(position).getSecenekB());
        holder.rbC.setText(questionsArrayList.get(position).getSecenekC());
        holder.rbD.setText(questionsArrayList.get(position).getSecenekD());

        holder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                holder.cbSinavaEkle.setChecked(!holder.cbSinavaEkle.isChecked());
                if(holder.cbSinavaEkle.isChecked())
                    onItemClick.onItemCheck(currentItem);
                else
                    onItemClick.onItemUncheck(currentItem);
            }
        });
    }

    @Override
    public int getItemCount() {
        return questionsArrayList.size();
    }



    public class RecyclerViewHolder extends RecyclerView.ViewHolder{

        TextView tvSoru,tvDogruSecenek;
        RadioGroup rgSecenekler;
        RadioButton rbA,rbB,rbC,rbD;
        CheckBox cbSinavaEkle;
        public RecyclerViewHolder(@NonNull View itemView) {
            super(itemView);

            cbSinavaEkle=itemView.findViewById(R.id.cbSinavaEkle);
            tvSoru=itemView.findViewById(R.id.tvSoru);
            tvDogruSecenek=itemView.findViewById(R.id.tvDogruSecenek);
            rgSecenekler=itemView.findViewById(R.id.rgSecenekler);
            rbA=itemView.findViewById(R.id.rbA);
            rbB=itemView.findViewById(R.id.rbB);
            rbC=itemView.findViewById(R.id.rbC);
            rbD=itemView.findViewById(R.id.rbD);

            cbSinavaEkle.setClickable(false);

        }
        public void setOnClickListener(View.OnClickListener onClickListener) {
            itemView.setOnClickListener(onClickListener);
        }
    }
}