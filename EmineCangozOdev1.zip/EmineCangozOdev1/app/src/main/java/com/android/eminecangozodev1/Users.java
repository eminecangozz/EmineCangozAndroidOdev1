package com.android.eminecangozodev1;

public class Users {
    private String ad;
    private String soyad;
    private String telefon;
    private String email;
    private String sifre;
    private String resim;

    public Users() {
    }

    public Users(String ad, String soyad, String telefon, String email, String sifre,
                 String resim) {
        this.ad = ad;
        this.soyad = soyad;
        this.telefon = telefon;
        this.email = email;
        this.sifre = sifre;
        this.resim = resim;
    }

    public String getAd() {
        return ad;
    }

    public void setAd(String ad) {
        this.ad = ad;
    }

    public String getSoyad() {
        return soyad;
    }

    public void setSoyad(String soyad) {
        this.soyad = soyad;
    }

    public String getTelefon() {
        return telefon;
    }

    public void setTelefon(String telefon) {
        this.telefon = telefon;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSifre() {
        return sifre;
    }

    public void setSifre(String sifre) {
        this.sifre = sifre;
    }

    public String getResim() {
        return resim;
    }

    public void setResim(String resim) {
        this.resim = resim;
    }

    @Override
    public String toString() {
        return "Users{" +
                "ad='" + ad + '\'' +
                ", soyad='" + soyad + '\'' +
                ", telefon='" + telefon + '\'' +
                ", email='" + email + '\'' +
                ", sifre='" + sifre + '\'' +
                ", resim='" + resim + '\'' +
                '}';
    }
}
