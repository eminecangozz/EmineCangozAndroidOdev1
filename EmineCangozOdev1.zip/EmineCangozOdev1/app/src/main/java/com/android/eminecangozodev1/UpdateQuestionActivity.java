package com.android.eminecangozodev1;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class UpdateQuestionActivity extends AppCompatActivity {
    EditText etSoruMetni, etSecenekA, etSecenekB, etSecenekC, etSecenekD, etDogruSecenek;
    RadioGroup rgZorlukSeviyesi;
    RadioButton rbSecili;
    String soruMetni, secenekA, secenekB, secenekC, secenekD;
    int dogruSecenek, zorlukSeviyesi;
    int guncellenecekSoruId;
    Questions q;
    private static final String TAG = "UpdateQuestionActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_question);
        tanimlamalar();
      


    }

    @Override
    protected void onResume() {
        super.onResume();
        guncellenecekSoruId = getIntent().getExtras().getInt("idGuncel");
        Log.d(TAG, "onResume: "+guncellenecekSoruId);
        QuizDbHelper dbHelper = new QuizDbHelper(this, 1);
        q = dbHelper.getOneQuestion(guncellenecekSoruId);
        verileriAlma();
    }

    private void tanimlamalar() {
        etSoruMetni = findViewById(R.id.etSoruMetni);
        etSecenekA = findViewById(R.id.etSecenekA);
        etSecenekB = findViewById(R.id.etSecenekB);
        etSecenekC = findViewById(R.id.etSecenekC);
        etSecenekD = findViewById(R.id.etSecenekD);
        etDogruSecenek = findViewById(R.id.etDogruSecenek);
        rgZorlukSeviyesi = findViewById(R.id.rgZorlukSeviyesi);
    }

    private void verileriAlma() {
        etSoruMetni.setText(q.getSoru());
        etSecenekA.setText(q.getSecenekA());
        etSecenekB.setText(q.getSecenekB());
        etSecenekC.setText(q.getSecenekC());
        etSecenekD.setText(q.getSecenekD());
        etDogruSecenek.setText(q.getDogruSecenek() + "");
        Toast.makeText(this, "seviye: "+q.getZorlukSeviyesi(), Toast.LENGTH_SHORT).show();
        for (int i = 0; i < rgZorlukSeviyesi.getChildCount(); i++) {
            RadioButton rButton = (RadioButton) rgZorlukSeviyesi.getChildAt(i);
            Log.d("rbutton", "verileriAlma: "+rButton.getText().toString());
            if (rButton.getText().toString().equals(q.getZorlukSeviyesi()+"")) {
                Log.d("rbutton", "verileriAlma: if sağlandı "+q.getZorlukSeviyesi());
                rButton.setChecked(true);
                return;
            }
        }
    }

    public void btnSoruGuncelleClick(View view) {
        soruMetni = etSoruMetni.getText().toString();
        secenekA = etSecenekA.getText().toString();
        secenekB = etSecenekB.getText().toString();
        secenekC = etSecenekC.getText().toString();
        secenekD = etSecenekD.getText().toString();
        dogruSecenek = Integer.parseInt(etDogruSecenek.getText().toString());
        rbSecili = findViewById(rgZorlukSeviyesi.getCheckedRadioButtonId());
       

        Questions q1 = new Questions(soruMetni, secenekA, secenekB, secenekC, secenekD, dogruSecenek,
                Integer.parseInt(rbSecili.getText().toString()));
        guncellenecekSoruId = getIntent().getExtras().getInt("idGuncel");
        Log.d(TAG, "btnSoruGuncelleClick: "+guncellenecekSoruId);
        QuizDbHelper dbHelper = new QuizDbHelper(this, 1);
        long sonuc = dbHelper.soruGuncelle(q1, guncellenecekSoruId);
        if (sonuc == -1) {
            Toast.makeText(this, "Soru Güncellenemedi!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Soru Başarılı Bir Şekilde Güncellendi.", Toast.LENGTH_SHORT).show();
        }
    }

    public void btnListeClick(View view) {
        Intent intent = new Intent(getApplicationContext(), ListQuestionActivity.class);
        startActivity(intent);
    }
}