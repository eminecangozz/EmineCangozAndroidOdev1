package com.android.eminecangozodev1;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddQuestionActivity extends AppCompatActivity {

    EditText etSoruMetni, etSecenekA, etSecenekB, etSecenekC, etSecenekD, etDogruSecenek;
    RadioGroup rgZorlukSeviyesi;
    RadioButton rbSecili;
    String soruMetni, secenekA, secenekB, secenekC, secenekD;
    int dogruSecenek, zorlukSeviyesi;
    SQLiteDatabase db;
    QuizDbHelper dbHelper;

    private static final String TAG = "AddQuestionActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_question);
        tanimlamalar();
        dbHelper=new QuizDbHelper(this,1);
    }
    private void verileriAlma() {

        soruMetni = etSoruMetni.getText().toString();
        secenekA = etSecenekA.getText().toString();
        secenekB = etSecenekB.getText().toString();
        secenekC = etSecenekC.getText().toString();
        secenekD = etSecenekD.getText().toString();
        dogruSecenek = Integer.parseInt(etDogruSecenek.getText().toString());
        rbSecili = findViewById(rgZorlukSeviyesi.getCheckedRadioButtonId());
    }

    private void tanimlamalar() {
        etSoruMetni = findViewById(R.id.etSoruMetni);
        etSecenekA = findViewById(R.id.etSecenekA);
        etSecenekB = findViewById(R.id.etSecenekB);
        etSecenekC = findViewById(R.id.etSecenekC);
        etSecenekD = findViewById(R.id.etSecenekD);
        etDogruSecenek = findViewById(R.id.etDogruSecenek);
        rgZorlukSeviyesi = findViewById(R.id.rgZorlukSeviyesi);
    }

    private void resetle() {
        etSoruMetni.getText().clear();
        etSecenekA.getText().clear();
        etSecenekB.getText().clear();
        etSecenekC.getText().clear();
        etSecenekD.getText().clear();
        etDogruSecenek.getText().clear();
        rgZorlukSeviyesi.clearCheck();
        db.close();
    }

    public void btnSoruEkleClick(View view) {
        db = this.openOrCreateDatabase("Test", MODE_PRIVATE, null);
        verileriAlma();
        Questions q1 = new Questions(soruMetni, secenekA, secenekB, secenekC, secenekD, dogruSecenek,
                Integer.parseInt(rbSecili.getText().toString()));

        try {
            dbHelper.soruekle(q1);
            Toast.makeText(this, "Soru veritabanına eklendi. \n Yeni soru ekleyebilirsiniz.",
                    Toast.LENGTH_SHORT).show();
            resetle();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Soru eklenemedi. Hata!", Toast.LENGTH_SHORT).show();
        }
    }
}